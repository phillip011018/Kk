﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace PKHeX.Controls
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class FlyoutHeader : ContentView
    {
        public FlyoutHeader()
        {
            InitializeComponent();
        }
    }
}