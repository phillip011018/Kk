﻿namespace PKHeX.Mobile.Logic
{
    public static class AppInfo
    {
        public const string GitHubLink = "https://github.com/kwsch/pkhex";
    }
}